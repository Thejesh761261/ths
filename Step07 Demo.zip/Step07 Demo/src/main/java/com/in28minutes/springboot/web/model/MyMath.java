package com.in28minutes.springboot.web.model;

public class MyMath {

    public int sum(int[] numbers) {
        int sum = 0;
        for (int i : numbers) {
            sum += i;
        }
        return sum;
    }
}
