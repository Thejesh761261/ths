package com.hospital.hospitalFrontDesk.resource;

import com.hospital.hospitalFrontDesk.entities.HospitalDetails;
import com.hospital.hospitalFrontDesk.entities.Specialists;
import com.hospital.hospitalFrontDesk.resource.model.SpecialistRequest;
import com.hospital.hospitalFrontDesk.service.SpecialistService;
import com.hospital.hospitalFrontDesk.service.model.SpecialistsResponse;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpecialistsDetailController {

    @Autowired
    SpecialistService specialistService;


    @RequestMapping("/hi")
    public String hi()
    {
        return "hi";
    }

    @RequestMapping("/getAllSpecialists")
    public List<Specialists> getAll()
    {
       return specialistService.getAll();
    }

    @RequestMapping("/getAllHospitals")
    public List<HospitalDetails> getAllHospitals()
    {
        return specialistService.getAllHospitals();
    }

    @GetMapping(value="${value}", produces ={ MediaType.APPLICATION_JSON_VALUE,
            MediaType.APPLICATION_XML_VALUE})
    @Cacheable(value="specialistsInfo")
    public List<SpecialistsResponse> getSpecialists(@RequestBody SpecialistRequest specialistRequest) {
        List<SpecialistsResponse> specialistsResponseList = specialistService.getSpecialists(specialistRequest);
        return specialistsResponseList;
    }

    @GetMapping(value="/specialists/{name}/{type}", produces ={ MediaType.APPLICATION_JSON_VALUE,
            MediaType.APPLICATION_XML_VALUE})
    @Cacheable(value="specialistsInfo")
    public List<SpecialistsResponse> specialists(@PathVariable("name") final String name,
                                                 @PathVariable("type")final String type ) {
        List<SpecialistsResponse> specialistsResponseList = specialistService.getSpecialists1(name,type);
        return specialistsResponseList;
    }


}
