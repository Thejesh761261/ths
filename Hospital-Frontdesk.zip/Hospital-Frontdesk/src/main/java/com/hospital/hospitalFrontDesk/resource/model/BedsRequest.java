package com.hospital.hospitalFrontDesk.resource.model;

public class BedsRequest {


    private String hospitalName;


    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public BedsRequest(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public BedsRequest() {
    }

    @Override
    public String toString() {
        return "BedsRequest{" +
                "hospitalName='" + hospitalName + '\'' +
                '}';
    }

}
