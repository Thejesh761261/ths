package com.hospital.hospitalFrontDesk.resource.model;

public class AppointmentRequest {

    private String specialistName;

    private  String desiredDay;

    private String patientName;

    public String getSpecialistName() {
        return specialistName;
    }

    public void setSpecialistName(String specialistName) {
        this.specialistName = specialistName;
    }

    public String getDesiredDay() {
        return desiredDay;
    }

    public void setDesiredDay(String desiredDay) {
        this.desiredDay = desiredDay;
    }

    public AppointmentRequest(String specialistName) {
        this.specialistName = specialistName;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public AppointmentRequest() {
    }

    @Override
    public String toString() {
        return "AppointmentRequest{" +
                "specialistName='" + specialistName + '\'' +
                ", desiredDay='" + desiredDay + '\'' +
                ", patientName='" + patientName + '\'' +
                '}';
    }
}
