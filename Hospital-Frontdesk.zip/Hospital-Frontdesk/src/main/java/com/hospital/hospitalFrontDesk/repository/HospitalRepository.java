package com.hospital.hospitalFrontDesk.repository;

import com.hospital.hospitalFrontDesk.entities.HospitalDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface HospitalRepository extends JpaRepository<HospitalDetails,Integer> {

    @Query(value="select * from hospital_details h where h.hospital_name=?1 ",nativeQuery=true)
    HospitalDetails findHospital(String name);


    @Query(value="select * from hospital_details h where h.hospital_name=?1 ",nativeQuery=true)
    HospitalDetails findHospitalDetails(String name);





}
