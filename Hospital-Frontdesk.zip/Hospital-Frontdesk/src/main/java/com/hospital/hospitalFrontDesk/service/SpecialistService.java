package com.hospital.hospitalFrontDesk.service;

import com.hospital.hospitalFrontDesk.entities.HospitalDetails;
import com.hospital.hospitalFrontDesk.entities.Specialists;
import com.hospital.hospitalFrontDesk.resource.model.SpecialistRequest;
import com.hospital.hospitalFrontDesk.service.model.SpecialistsResponse;
import java.util.List;

public interface SpecialistService {

    List<Specialists> getAll();

    List<HospitalDetails> getAllHospitals();

    List<SpecialistsResponse> getSpecialists(SpecialistRequest specialistRequest);

    List<SpecialistsResponse> getSpecialists1(String name,String type);
}
