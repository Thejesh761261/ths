package com.hospital.hospitalFrontDesk.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.stereotype.Component;

@Entity
@Component
@XmlRootElement
@Table(name="patients")
public class Patients {

    @Id
    @GeneratedValue
    @Column(name="id")
    private int id;

    @Column(name="hospital_id")
   private int hospitalId;

    @Column(name="name")
   private String name;

    @Column(name="age")
   private int age;

    @Column(name="specialist")
   private  String specialist;

    @Column(name="status")
   private String status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(int hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSpecialist() {
        return specialist;
    }

    public void setSpecialist(String specialist) {
        this.specialist = specialist;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Patients() {
    }

    public Patients(int id, int hospitalId, String name, int age, String specialist, String status) {
        this.id = id;
        this.hospitalId = hospitalId;
        this.name = name;
        this.age = age;
        this.specialist = specialist;
        this.status = status;
    }
}
