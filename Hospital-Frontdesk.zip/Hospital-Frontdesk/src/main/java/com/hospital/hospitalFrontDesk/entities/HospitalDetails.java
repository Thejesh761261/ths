package com.hospital.hospitalFrontDesk.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "hospital_details")
public class HospitalDetails {

    @Id
    @GeneratedValue
    @NotNull
    @Column(name="id")
    private int id;

    @Column(name="hospitalId")
    private int hospitalId;

    @Column(name="hospitalName")
    private String name;

    @Column(name="totalBeds")
    private int totalBeds;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(int hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTotalBeds() {
        return totalBeds;
    }

    public void setTotalBeds(int totalBeds) {
        this.totalBeds = totalBeds;
    }

    public HospitalDetails() {
    }

    public HospitalDetails(int id, int hospitalId, String name, int totalBeds) {
        this.id = id;
        this.hospitalId = hospitalId;
        this.name = name;
        this.totalBeds = totalBeds;
    }

    @Override
    public String toString() {
        return "HospitalDetails{" +
                "id=" + id +
                ", hospitalId='" + hospitalId + '\'' +
                ", name='" + name + '\'' +
                ", totalBeds=" + totalBeds +
                '}';
    }
}
