package com.hospital.hospitalFrontDesk.service;

import com.hospital.hospitalFrontDesk.entities.Appointment;
import com.hospital.hospitalFrontDesk.resource.model.AppointmentRequest;

public interface AppointmentService {

   Appointment requestAppointment(AppointmentRequest appointmentRequest);

   int getBeds(String hospital);

    Appointment getAppointment(String specialistName, String desiredDay, String patientName);
}
