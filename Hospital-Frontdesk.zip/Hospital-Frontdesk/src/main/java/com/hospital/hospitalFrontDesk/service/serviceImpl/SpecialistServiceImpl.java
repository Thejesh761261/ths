package com.hospital.hospitalFrontDesk.service.serviceImpl;

import com.hospital.hospitalFrontDesk.entities.HospitalDetails;
import com.hospital.hospitalFrontDesk.entities.Specialists;
import com.hospital.hospitalFrontDesk.exception.RecordNotFoundException;
import com.hospital.hospitalFrontDesk.repository.HospitalRepository;
import com.hospital.hospitalFrontDesk.repository.SpecialistsRepository;
import com.hospital.hospitalFrontDesk.resource.model.SpecialistRequest;
import com.hospital.hospitalFrontDesk.service.SpecialistService;
import com.hospital.hospitalFrontDesk.service.model.SpecialistsResponse;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SpecialistServiceImpl implements SpecialistService {

    @Autowired
    SpecialistsRepository specialistsRepository;

    @Autowired
    HospitalRepository hospitalRepository;

    @Override
    public List<Specialists> getAll() {

        return specialistsRepository.findAll();
    }

    @Override
    public List<HospitalDetails> getAllHospitals() {
        return hospitalRepository.findAll();
    }

    @Override
    public List<SpecialistsResponse> getSpecialists(SpecialistRequest specialistRequest) {
        HospitalDetails hospitalDetails= hospitalRepository.findHospital(specialistRequest.getHospital_name());

        if(hospitalDetails==null)
        {
            throw new RecordNotFoundException("The hospital name you entered is incorrect or does'nt exist");
        }
        int id=hospitalDetails.getHospitalId();
        String hospitalName = specialistRequest.getHospital_name();

        List<Specialists> specialistsList = specialistsRepository.findSpecialists(id,
                specialistRequest.getSpecialist_type());
        if(specialistsList.size()==0)
        {
            throw new RecordNotFoundException("The specialist of desired type does not exist");
        }

        List<SpecialistsResponse> specialistsResponseList = new ArrayList<>();
        for (Specialists specialists : specialistsList) {
            SpecialistsResponse specialistsResponse = new SpecialistsResponse();
            specialistsResponse.setHospitalname(hospitalName);
            specialistsResponse.setHospitalId(specialists.getHospitalId());
            specialistsResponse.setName(specialists.getName());
            specialistsResponse.setType(specialists.getType());
            specialistsResponse.setAvailableday(specialists.getAvailableDay());
            specialistsResponse.setAvailableTime(specialists.getGetAvailableTime());
            specialistsResponse.setIsAvailable(specialists.getIsAvailable());
            specialistsResponseList.add(specialistsResponse);
        }

        return specialistsResponseList;
    }

    @Override
    public List<SpecialistsResponse> getSpecialists1(String name, String type) {
        HospitalDetails hospitalDetails= hospitalRepository.findHospital(name);

        if(hospitalDetails==null)
        {
            throw new RecordNotFoundException("The hospital name you entered is incorrect or does'nt exist");
        }
        int id=hospitalDetails.getHospitalId();
        String hospitalName = name;

        List<Specialists> specialistsList = specialistsRepository.findSpecialists(id,
                type);
        if(specialistsList.size()==0)
        {
            throw new RecordNotFoundException("The specialist of desired type does not exist");
        }

        List<SpecialistsResponse> specialistsResponseList = new ArrayList<>();
        for (Specialists specialists : specialistsList) {
            SpecialistsResponse specialistsResponse = new SpecialistsResponse();
            specialistsResponse.setHospitalname(hospitalName);
            specialistsResponse.setHospitalId(specialists.getHospitalId());
            specialistsResponse.setName(specialists.getName());
            specialistsResponse.setType(specialists.getType());
            specialistsResponse.setAvailableday(specialists.getAvailableDay());
            specialistsResponse.setAvailableTime(specialists.getGetAvailableTime());
            specialistsResponse.setIsAvailable(specialists.getIsAvailable());
            specialistsResponseList.add(specialistsResponse);
        }

        return specialistsResponseList;
    }
}
