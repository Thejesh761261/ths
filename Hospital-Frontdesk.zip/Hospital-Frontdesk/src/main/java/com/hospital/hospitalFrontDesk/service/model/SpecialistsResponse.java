package com.hospital.hospitalFrontDesk.service.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SpecialistsResponse {

    private String type;

    private String name;

    private  String hospitalname;

    private String availableday;

    private String availableTime;

    private  String isAvailable;

    private int hospitalId;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAvailableday() {
        return availableday;
    }

    public void setAvailableday(String availableday) {
        this.availableday = availableday;
    }

    public String getAvailableTime() {
        return availableTime;
    }

    public void setAvailableTime(String availableTime) {
        this.availableTime = availableTime;
    }

    public String getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(String isAvailable) {
        this.isAvailable = isAvailable;
    }

    public int getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(int hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getHospitalname() {
        return hospitalname;
    }

    public void setHospitalname(String hospitalname) {
        this.hospitalname = hospitalname;
    }

    public SpecialistsResponse(String type, String name, String hospitalname, String availableday,
                               String availableTime, String isAvailable, int hospitalId) {
        this.type = type;
        this.name = name;
        this.hospitalname = hospitalname;
        this.availableday = availableday;
        this.availableTime = availableTime;
        this.isAvailable = isAvailable;
        this.hospitalId = hospitalId;
    }

    public SpecialistsResponse() {
    }

    @Override
    public String toString() {
        return "SpecialistsResponse{" +
                "type='" + type + '\'' +
                ", name='" + name + '\'' +
                ", hospitalname='" + hospitalname + '\'' +
                ", availableday='" + availableday + '\'' +
                ", availableTime='" + availableTime + '\'' +
                ", isAvailable='" + isAvailable + '\'' +
                ", hospitalId=" + hospitalId +
                '}';
    }
}
