package com.hospital.hospitalFrontDesk.repository;

import com.hospital.hospitalFrontDesk.entities.Patients;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientRepository extends JpaRepository<Patients,Integer> {
    @Query(value="select * from patients where hospital_id=?1 ",nativeQuery=true)
    List<Patients> getAllById(int id);
}
