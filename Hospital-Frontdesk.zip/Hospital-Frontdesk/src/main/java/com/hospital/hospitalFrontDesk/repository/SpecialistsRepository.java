package com.hospital.hospitalFrontDesk.repository;

import com.hospital.hospitalFrontDesk.entities.Specialists;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SpecialistsRepository extends JpaRepository<Specialists,Integer> {

    @Query(value="select * from specialists_details s where s.hospital_id=?1 and s.type=?2",
            nativeQuery=true)
    List<Specialists> findSpecialists(int id, String type);

    @Query(value="select * from specialists_details s where s.name=?1",nativeQuery = true)
    Specialists findAvailability(String name);
}
