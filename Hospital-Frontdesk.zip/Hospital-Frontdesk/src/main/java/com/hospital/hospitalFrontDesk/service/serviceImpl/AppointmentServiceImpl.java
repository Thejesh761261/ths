package com.hospital.hospitalFrontDesk.service.serviceImpl;

import com.hospital.hospitalFrontDesk.entities.Appointment;
import com.hospital.hospitalFrontDesk.entities.HospitalDetails;
import com.hospital.hospitalFrontDesk.entities.Patients;
import com.hospital.hospitalFrontDesk.entities.Specialists;
import com.hospital.hospitalFrontDesk.exception.RecordNotFoundException;
import com.hospital.hospitalFrontDesk.repository.AppointmentRepository;
import com.hospital.hospitalFrontDesk.repository.HospitalRepository;
import com.hospital.hospitalFrontDesk.repository.PatientRepository;
import com.hospital.hospitalFrontDesk.repository.SpecialistsRepository;
import com.hospital.hospitalFrontDesk.resource.model.AppointmentRequest;
import com.hospital.hospitalFrontDesk.service.AppointmentService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
@PropertySource("classpath:specialist.properties")
public class AppointmentServiceImpl implements AppointmentService {

    @Autowired
    SpecialistsRepository specialistsRepository;

    @Autowired
    AppointmentRepository appointmentRepository;

    @Autowired
    HospitalRepository hospitalRepository;

    @Autowired
    PatientRepository patientRepository;

    @Autowired
    private Environment environment;

    Appointment appointment;


    public AppointmentServiceImpl(Appointment appointment) {
        this.appointment = appointment;
    }

    @Override
    public Appointment requestAppointment(AppointmentRequest appointmentRequest) {

        String specialist = appointmentRequest.getSpecialistName();
        String availableDay = appointmentRequest.getDesiredDay();
        Specialists specialists = specialistsRepository.findAvailability(specialist);

        if(specialists==null)
        {
            throw new RecordNotFoundException("Entered Specialist name is incorrect or does not exist");
        }

        String str = specialists.getAvailableDay();

        if (str.contains(availableDay)) {
            appointment.setAppointmentDay(availableDay);
            appointment.setAppointmentTime(specialists.getGetAvailableTime());
            appointment.setSpecialistName(specialist);
            appointment.setPatient_name(appointmentRequest.getPatientName());
            appointmentRepository.save(appointment);
        } else {
            throw new RecordNotFoundException("Doctor is not available in your desired day");
        }

        return appointment;
    }

    @Override
    public int getBeds(String hospital) {

        HospitalDetails hospitalDetails = hospitalRepository.findHospitalDetails(hospital);
        if(hospitalDetails==null)
        {
            throw new RecordNotFoundException("The hospital name you entered is incorrect or does'nt exist");
        }
        int id = 0;
        int beds = 0;
        int k = 0;
        id = hospitalDetails.getHospitalId();
        beds = hospitalDetails.getTotalBeds();

        List<Patients> patients = patientRepository.getAllById(id);
        for (Patients patients1 : patients) {
            if (!patients1.getStatus().equals("DISCHARGE")) {
                k++;
            }
        }

        return beds - k;
    }

    @Override
    public Appointment getAppointment(String specialistName, String desiredDay, String patientName) {
        String str=specialistName+".details";
        List<String> stringList=environment.getRequiredProperty(str,List.class);
        Appointment appointment=new Appointment();
        appointment.setSpecialistName(specialistName);
        appointment.setPatient_name(patientName);
        String str1=stringList.get(0);
        if(!str1.contains(desiredDay))
        {
            throw new RecordNotFoundException("Doctor is not available in your desired day");
        }else{
            appointment.setAppointmentDay(desiredDay);
        }
        appointment.setAppointmentTime(stringList.get(1));

        return appointment;
    }
}
