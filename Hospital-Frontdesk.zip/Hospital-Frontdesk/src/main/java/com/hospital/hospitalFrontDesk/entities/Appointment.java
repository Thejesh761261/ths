package com.hospital.hospitalFrontDesk.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.stereotype.Component;

@Entity
@Component
@XmlRootElement
@Table(name="appointments")
public class Appointment {

    @Id
    @GeneratedValue
    @Column(name="id")
    private int id;

    @Column(name="specialist_name")
    private String specialistName;

    @Column(name="patient_name")
    private String patient_name;

    @Column(name="appointment_day")
    private String appointmentDay;

    @Column(name="appointment_time")
    private String appointmentTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSpecialistName() {
        return specialistName;
    }

    public void setSpecialistName(String specialistName) {
        this.specialistName = specialistName;
    }

    public String getPatient_name() {
        return patient_name;
    }

    public void setPatient_name(String patient_name) {
        this.patient_name = patient_name;
    }

    public String getAppointmentDay() {
        return appointmentDay;
    }

    public void setAppointmentDay(String appointmentDay) {
        this.appointmentDay = appointmentDay;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public Appointment() {
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "id=" + id +
                ", specialistName='" + specialistName + '\'' +
                ", patient_name='" + patient_name + '\'' +
                ", appointmentDay='" + appointmentDay + '\'' +
                ", appointmentTime='" + appointmentTime + '\'' +
                '}';
    }
}
