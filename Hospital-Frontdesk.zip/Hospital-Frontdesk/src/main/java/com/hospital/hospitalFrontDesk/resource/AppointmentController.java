package com.hospital.hospitalFrontDesk.resource;

import com.hospital.hospitalFrontDesk.entities.Appointment;
import com.hospital.hospitalFrontDesk.resource.model.AppointmentRequest;
import com.hospital.hospitalFrontDesk.resource.model.BedsRequest;
import com.hospital.hospitalFrontDesk.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppointmentController {

    @Autowired
    AppointmentService appointmentService;

    @GetMapping(value = "${appointment}", produces = {MediaType.APPLICATION_JSON_VALUE,
            MediaType.APPLICATION_XML_VALUE})
    public Appointment getAppointment(@RequestBody AppointmentRequest appointmentRequest) {
        return appointmentService.requestAppointment(appointmentRequest);
    }

    @GetMapping(value = "${appoint}", produces = {MediaType.APPLICATION_JSON_VALUE,
            MediaType.APPLICATION_XML_VALUE})
    public Appointment getAppointments(@RequestBody AppointmentRequest appointmentRequest) {

        return appointmentService.getAppointment(appointmentRequest.getSpecialistName(),
                appointmentRequest.getDesiredDay(),appointmentRequest.getPatientName());
    }


    @PostMapping("${beds}")
    public String getBedsCount(@RequestBody BedsRequest bedsRequest) {
        String name = bedsRequest.getHospitalName();
        int sum = appointmentService.getBeds(name);
        return "The number of beds available is = " + sum;
    }
}
