package com.hospital.hospitalFrontDesk.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="specialists_details")
public class Specialists {

    @Id
    @Column
    @NotNull
    private int id;

    @Column
    private int hospitalId;

    @Column
    private String Name;

    @Column
    private String Type;

    @Column
    private String availableDay;

    @Column
    private String getAvailableTime;

    @Column
    private String  isAvailable;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getAvailableDay() {
        return availableDay;
    }

    public void setAvailableDay(String availableDay) {
        this.availableDay = availableDay;
    }

    public String getGetAvailableTime() {
        return getAvailableTime;
    }

    public void setGetAvailableTime(String getAvailableTime) {
        this.getAvailableTime = getAvailableTime;
    }

    public int getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(int hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(String isAvailable) {
        this.isAvailable = isAvailable;
    }

    public Specialists(@NotNull int id, int hospitalId, String name, String type, String availableDay,
                       String getAvailableTime, String isAvailable) {
        this.id = id;
        this.hospitalId = hospitalId;
        Name = name;
        Type = type;
        this.availableDay = availableDay;
        this.getAvailableTime = getAvailableTime;
        this.isAvailable = isAvailable;
    }

    public Specialists() {
    }

    @Override
    public String toString() {
        return "Specialists{" +
                "id=" + id +
                ", hospitalId='" + hospitalId + '\'' +
                ", Name='" + Name + '\'' +
                ", Type='" + Type + '\'' +
                ", availableDay='" + availableDay + '\'' +
                ", getAvailableTime='" + getAvailableTime + '\'' +
                ", isAvailable=" + isAvailable +
                '}';
    }
}
