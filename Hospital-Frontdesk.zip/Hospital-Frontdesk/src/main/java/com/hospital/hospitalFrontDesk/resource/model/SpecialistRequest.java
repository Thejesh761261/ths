package com.hospital.hospitalFrontDesk.resource.model;

public class SpecialistRequest {

    private String hospital_name;

    private String specialist_type;

    public String getHospital_name() {
        return hospital_name;
    }

    public void setHospital_name(String hospital_name) {
        this.hospital_name = hospital_name;
    }

    public String getSpecialist_type() {
        return specialist_type;
    }

    public void setSpecialist_type(String specialist_type) {
        this.specialist_type = specialist_type;
    }

    public SpecialistRequest(String hospital_name, String specialist_type) {
        this.hospital_name = hospital_name;
        this.specialist_type = specialist_type;
    }

    public SpecialistRequest() {
    }

    @Override
    public String toString() {
        return "SpecialistRequest{" +
                "hospital_name='" + hospital_name + '\'' +
                ", specialist_type='" + specialist_type + '\'' +
                '}';
    }
}
