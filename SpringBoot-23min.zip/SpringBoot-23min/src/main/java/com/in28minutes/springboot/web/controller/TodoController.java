package com.in28minutes.springboot.web.controller;

import com.in28minutes.springboot.web.model.Todo;
import com.in28minutes.springboot.web.service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
@SessionAttributes("name")
public class TodoController {

    @Autowired
    TodoService todoService;


    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        binder.registerCustomEditor(Date.class, new CustomDateEditor(
                dateFormat, false));
    }

    @RequestMapping(value="/todo-lists", method = RequestMethod.GET)
    public String showTodos(ModelMap model){
        String name= getLoggedinUserName(model);
        System.out.println(name);
        model.put("todos",todoService.retrieveTodos(name));
        return "todo-list";
    }

    private String getLoggedinUserName(ModelMap model) {
        return (String) model.get("name");
    }

    @RequestMapping(value="/add-todo", method = RequestMethod.GET)
    public String addTodo(ModelMap model){

        model.addAttribute("todo",new Todo(0, getLoggedinUserName(model),"Add Todo",new Date(),false));

        return "todo";
    }

    @RequestMapping(value="/delete-todo", method = RequestMethod.GET)
    public String deleteTodo(@RequestParam int id) throws Exception {
        if(id==1){
            throw new Exception("Unhandled error for ID:1");
        }
        todoService.deleteTodo(id);
        return "redirect:/todo-lists";
    }

    @RequestMapping(value="/update-todo", method = RequestMethod.GET)
    public String retriveTodo(ModelMap model,@RequestParam int id){
       Todo todo =  todoService.retriveTodo(id);
       model.put("todo",todo);
        return "todo";
    }

    @RequestMapping(value="/update-todo", method = RequestMethod.POST)
    public String updateTodo(ModelMap model,@Valid Todo todo, BindingResult result){
        if(result.hasErrors()){
            return "todo";
        }
        todo.setUser(getLoggedinUserName(model));
        todoService.updateTodo(todo);
        return "redirect:/todo-lists";
    }

    @RequestMapping(value="/add-todo", method = RequestMethod.POST)
    public String addTodoToArray(ModelMap model, @Valid Todo todo, BindingResult result){
        if(result.hasErrors()){
            return "todo";
        }
        todoService.addTodo(getLoggedinUserName(model),todo.getDesc(),todo.getTargetDate(),false);
        return "redirect:/todo-lists";
    }
}
