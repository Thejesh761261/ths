package com.in28minutes.springboot.web.model;

public interface MockitoDemoInterface {

    int[] retrieveAllData();
}
