package com.in28minutes.springboot.web.model;

public class MockitoDemoImpl  {

    private MockitoDemoInterface mockitoDemoInterface;

    public MockitoDemoImpl(MockitoDemoInterface mockitoDemoInterface){
        super();
        this.mockitoDemoInterface=mockitoDemoInterface;
    }

   public int findTheGreatestFromAllData() {
        int[] data = mockitoDemoInterface.retrieveAllData();
        int greatest = Integer.MIN_VALUE;

        for (int value : data) {
            if (value > greatest) {
                greatest = value;
            }
        }
        return greatest;
    }
    }
