package com.in28minutes.springboot.web;

import com.in28minutes.springboot.web.model.MyMath;
import org.junit.*;

import static org.junit.Assert.assertEquals;

public class MyMathTest {

    MyMath math=new MyMath();

    @Before
    public void before() {
        System.out.println("Before");
    }

    @After
    public void after() {
        System.out.println("After");
    }

    @BeforeClass
    public static void beforeClass() {
        System.out.println("Before Class");
    }

    @AfterClass
    public static void afterClass() {
        System.out.println("After Class");
    }

    @Test
    public void testSum(){
            assertEquals(6,math.sum(new int[]{1,3,2}));
    }

    @Test
    public void testSumWith_1arg(){
        assertEquals(5,math.sum(new int[]{5}));
    }
}
