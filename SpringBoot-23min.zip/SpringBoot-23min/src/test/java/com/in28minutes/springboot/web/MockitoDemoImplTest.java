package com.in28minutes.springboot.web;

import com.in28minutes.springboot.web.model.MockitoDemoImpl;
import com.in28minutes.springboot.web.model.MockitoDemoInterface;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class MockitoDemoImplTest {

    @Mock
    MockitoDemoInterface mockitoDemoInterface;

    @InjectMocks
    MockitoDemoImpl mockitoDemo;

    @Test
    public void testFindGreatestFromAllTheData(){
        when(mockitoDemoInterface.retrieveAllData()).thenReturn(new int[]{1,2,33,21});
        assertEquals(33,mockitoDemo.findTheGreatestFromAllData());
    }

    @Test
    public void testFindGreatestFromAllData_ForOneValue(){
        when(mockitoDemoInterface.retrieveAllData()).thenReturn(new int[]{43}).thenReturn(new int[]{1,2,3});
        assertEquals(43,mockitoDemo.findTheGreatestFromAllData());
        assertEquals(3,mockitoDemo.findTheGreatestFromAllData());
        assertEquals(3,mockitoDemo.findTheGreatestFromAllData());
    }

    @Test
    public void testFindGreatestFromAllData_ForNoValue(){
        when(mockitoDemoInterface.retrieveAllData()).thenReturn(new int[]{});
        assertEquals(Integer.MIN_VALUE,mockitoDemo.findTheGreatestFromAllData());
    }

}
