package com.example.demo.service;

import com.example.demo.document.Users;

public interface UserService {

    public Users createUser(Users user);
}
