package com.example.demo.config;

import com.example.demo.document.Users;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import com.example.demo.repository.UserRepository;

@EnableMongoRepositories(basePackageClasses = UserRepository.class)
@Configuration
public class MongoDBConfig {


    @Bean
    CommandLineRunner commandLineRunner(UserRepository userRepository)
    {
        return new CommandLineRunner(){

            @Override
            public void run(String... args) throws Exception{

                userRepository.save(new Users(1,"Thejesh",250000L,"Macys"));
                userRepository.save(new Users(2,"Rajesh",200000L,"Macys"));
                userRepository.save(new Users(3,"Mahesh",350000L,"Macys"));

            }
        };
    }
}
