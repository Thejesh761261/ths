package com.example.demo.resource;

import com.example.demo.document.Users;

import com.example.demo.service.UserService;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.repository.UserRepository;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/mongoTest")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @GetMapping("/users")
    public List<Users> getAll(){
        return userRepository.findAll();
    }

    @PostMapping("/create")
    public Users createUser(@Valid @RequestBody Users users)
    {
        Users user= userService.createUser(users);
        return user;
    }

    @GetMapping("/hello")
    public String hello()
    {
        return "Hello from producer";
    }

}
