package com.example.demo.service;

import com.example.demo.document.Users;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepository;

    @Override
    public Users createUser(Users users)
    {
        return userRepository.save(new Users(users.getId(),users.getName(),users.getSalary(),users.getProject()));
    }


}
