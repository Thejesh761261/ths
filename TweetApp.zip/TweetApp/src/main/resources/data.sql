INSERT INTO `tweets` (`id`, `userId`,`createdBy`, `createdTs`,`tweet`) VALUES (1, 'thejesh@gmail.com','thejesh', PARSEDATETIME('26 Jul 2019, 05:15:58 AM','dd MMM yyyy, hh:mm:ss a','en'),'This is my first tweet');
INSERT INTO `tweets` (`id`, `userId`, `createdBy`, `createdTs`,`tweet`) VALUES (2, 'thejesh@gmail.com','thejesh', PARSEDATETIME('05 Jun 2020, 05:15:58 AM','dd MMM yyyy, hh:mm:ss a','en'),'This is my second tweet');
INSERT INTO `tweets` (`id`, `userId`, `createdBy`, `createdTs`,`tweet`) VALUES (3, 'thej@gmail.com','thej',PARSEDATETIME('23 Mar 2019, 05:15:58 AM','dd MMM yyyy, hh:mm:ss a','en'),'This is my first tweet');


INSERT INTO `users` (`id`, `email`, `password`, `firstname`,`lastname`,`gender`,`dob`) VALUES (1, 'thejesh@gmail.com','thej', 'Thejesh','K','male',PARSEDATETIME('26 Jul 2016, 05:15:58 AM','dd MMM yyyy, hh:mm:ss a','en'));
INSERT INTO `users` (`id`, `email`, `password`, `firstname`,`lastname`,`gender`,`dob`) VALUES (2, 'thej@gmail.com','thej', 'Theju','K','female',PARSEDATETIME('26 Jul 2016, 05:15:58 AM','dd MMM yyyy, hh:mm:ss a','en'));