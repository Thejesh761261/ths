//package com.tweet.springboot.web.service;
//
//import com.tweet.springboot.web.model.User;
//import com.tweet.springboot.web.repository.UserRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Service;
//import org.springframework.util.StringUtils;
//
//@Service
//public class UserServiceImpl implements UserService {
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Autowired
//    private BCryptPasswordEncoder passwordEncoder;
//
//    public User findByEmail(String email){
//        return userRepository.findByEmail(email);
//    }
//
//    public Boolean validateLogin(String email,String password){
//        User user =  userRepository.findByEmail(email);
//        Boolean validUser = false;
//        if(!StringUtils.isEmpty(user)){
//            if(user.getPassword().equals(password)){
//                validUser = true;
//            }else{
//                validUser =  false;
//            }
//        }
//        return validUser;
//    }
//
//
//    public User save(User registration){
//        User user = new User();
//        user.setFirstName(registration.getFirstName());
//        user.setLastName(registration.getLastName());
//        user.setEmail(registration.getEmail());
//        user.setPassword(passwordEncoder.encode(registration.getPassword()));
//        user.setDob(registration.getDob());
//        user.setGender(registration.getGender());
//        return userRepository.save(user);
//    }
//
//}