package com.tweet.springboot.web.model;

import org.hibernate.validator.constraints.Email;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Date;

public class Tweet {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @Email
    private String userId;
    @Size(max=50,message = "Max limit is is 50 characters")
    private String tweet;
    private Date createdTs;
    private String createdBy;

    public Tweet() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTweet() {
        return tweet;
    }

    public void setTweet(String tweet) {
        this.tweet = tweet;
    }

    public Date getCreatedTs() {
        return createdTs;
    }

    public void setCreatedTs(Date createdTs) {
        this.createdTs = createdTs;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Tweet(int id, String userId, String tweet, Date createdTs, String createdBy) {
        this.id = id;
        this.userId = userId;
        this.tweet = tweet;
        this.createdTs = createdTs;
        this.createdBy = createdBy;
    }

    @Override
    public String toString() {
        return "Tweet{" +
                "id=" + id +
                ", userId='" + userId + '\'' +
                ", tweet='" + tweet + '\'' +
                ", createdTs=" + createdTs +
                ", createdBy='" + createdBy + '\'' +
                '}';
    }
}
