package com.tweet.springboot.web.service;

import com.tweet.springboot.web.model.Tweet;
import org.springframework.stereotype.Component;
import java.util.Date;
import java.util.List;

@Component
public interface TweetService {
    public List<Tweet> retrieveTweets(String user);
    public void updateTweet(Tweet tweet);
    public void addTweet(Tweet tweet);
    public void deleteTweet(int id);
}
