package com.tweet.springboot.web;

import com.tweet.springboot.web.model.Tweet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTweetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTweetApplication.class, args);
	}

}
