package com.tweet.springboot.web.service;

import com.tweet.springboot.web.model.Tweet;
import com.tweet.springboot.web.repository.TweetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@Service
public class TweetServiceImpl implements TweetService{

    @Autowired
    TweetRepository tweetRepository;
    private static List<Tweet> tweets = new ArrayList<>();
    private static int tweetCount = 3;
    static {
        tweets.add(new Tweet(1, "thejesh@gmail.com","This is my first tweet", new Date(),"thejesh"));
        tweets.add(new Tweet(2, "thejesh@gmail.com","This is my second tweet", new Date(),"thejesh"));
        tweets.add(new Tweet(3, "thej@gmail.com","This is my first tweet", new Date(),"theju"));
    }

    public List<Tweet> retrieveTweets(String user) {
//        List<Tweet> filteredTweets = new ArrayList<Tweet>();
//        for (Tweet tweet : tweets) {
////            if (tweet.createdBy().equals(user)) {
////                filteredTweets.add(todo);
////            }
//            filteredTweets.add(tweet);
//        }
//        return filteredTweets;
        List<Tweet> tweets = tweetRepository.getAllTweets();
        return tweets;
    }

    public List<Tweet> retrieveMyTweets(String userId) {
        List<Tweet> tweets = tweetRepository.yourTweets(userId);
        return tweets;
    }

    public Tweet retriveTweet(int id) {
        for (Tweet tweet : tweets) {
            if (tweet.getId()==id) {
                return tweet;
            }
        }
        return null;
    }

    public void updateTweet(Tweet tweet){
        tweets.remove(tweet);
        tweets.add(tweet);
    }

    public void addTweet(Tweet tweet) {
        tweetRepository.addTweet(++tweetCount, "thejesh@gmail.com", tweet.getTweet(), new Date(), "thejesh");
    }

    public void deleteTweet(int id) {
        Iterator<Tweet> iterator = tweets.iterator();
        while (iterator.hasNext()) {
            Tweet tweet = iterator.next();
            if (tweet.getId() == id) {
                iterator.remove();
            }
        }
    }
}
