package com.tweet.springboot.web.service;

import com.tweet.springboot.web.model.User;

public interface UserService {
    User findByEmail(String email);

    User save(User registration);
}
