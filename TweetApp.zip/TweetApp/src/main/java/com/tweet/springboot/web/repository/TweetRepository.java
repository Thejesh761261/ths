package com.tweet.springboot.web.repository;

import com.tweet.springboot.web.model.Tweet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.Date;
import java.util.List;

@Repository
public class TweetRepository {

    @Autowired
    JdbcTemplate template;

    public List<Tweet> getAllTweets(){
        List<Tweet> tweets = template.query("select id,userId,tweet,createdTs,createdBy from tweets", (result, rowNum) -> new Tweet(result.getInt("id"),result.getString("userId"),
                result.getString("tweet"),result.getDate("createdTs"), result.getString("createdBy")));
        return tweets;
    }

    public List<Tweet> yourTweets(String userId) {
        String query = "SELECT * FROM TWEETS WHERE USERID=?";
        List<Tweet> yourTweets = template.query(query, new Object[]{userId}, new BeanPropertyRowMapper<>(Tweet.class));
        return yourTweets;
    }

    public int addTweet(int id, String userId, String tweet, Date createdTs, String createdBy) {
        String query = "INSERT INTO TWEETS VALUES(?,?,?,?,?)";
        return template.update(query, id, userId,createdBy,createdTs,tweet);
    }

    public int deleteTweet(int id) {
        String query = "DELETE FROM TWEETS WHERE ID =?";
        return template.update(query, id);
    }
}

