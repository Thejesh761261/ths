package com.tweet.springboot.web.controller;

import com.tweet.springboot.web.model.Tweet;
import com.tweet.springboot.web.service.TweetServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.Date;

@Controller
public class TweetController {

    @Autowired
    private TweetServiceImpl tweetService;

    @GetMapping(value="/tweets")
    public String showTweets(ModelMap model){
        String name= getLoggedInUserName();
        model.put("tweets", tweetService.retrieveTweets(name));
        return "tweet-list";
    }

    @GetMapping(value="/myTweets")
    public String yourTweets(ModelMap model){
        String name= getLoggedInUserName();
        model.put("tweets", tweetService.retrieveMyTweets(getLoggedInUserName()));
        return "tweet-list";
    }

    @GetMapping(value="/")
    public String tweets(ModelMap model){
        String name= getLoggedInUserName();
        model.put("tweets", tweetService.retrieveTweets(name));
        return "tweet-list";
    }

    @GetMapping(value="/add-tweet")
    public String addTweet(ModelMap model){
        model.addAttribute("tweet",new Tweet(0, "thejesh@gmail.com","Write Tweet",new Date(),getLoggedInUserName()));
        return "tweet";
    }

    @GetMapping(value="/delete-tweet")
    public String deleteTweet(@RequestParam int id) throws Exception {
        tweetService.deleteTweet(id);
        return "redirect:/tweets";
    }

    @PostMapping(value="/update-tweet")
    public String updateTweet(ModelMap model, @Valid Tweet tweet, BindingResult result){
        if(result.hasErrors()){
            return "tweet";
        }
        tweet.setCreatedBy(getLoggedInUserName());
        tweetService.updateTweet(tweet);
        return "redirect:/tweets";
    }

    @PostMapping(value="/add-tweet")
    public String addTweetToArray(ModelMap model, @Valid Tweet tweet, BindingResult result){
        if(result.hasErrors()){
            return "tweet";
        }
        tweetService.addTweet(tweet);
        return "redirect:/tweets";
    }


    private  String getLoggedInUserName(){

        Object principal= SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if(principal instanceof UserDetails){
            return ((UserDetails)principal).getUsername();
        }
        return principal.toString();
    }

}
