package com.example.demo.client;

import com.example.demo.client.model.GetNotesClientRequest;
import com.example.demo.client.model.NoteClientResponse;
import com.example.demo.client.model.NotesClientResponse;
import com.example.demo.client.model.NotesRoot;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class GetNotesServiceClient {

    public NotesRoot getNotes(GetNotesClientRequest getNotesClientRequest) {
        String reservationNumber = getNotesClientRequest.getReservationNumber();

        File file = new File("C:\\Users\\761282\\projects\\demo1\\src\\main\\java\\com\\example\\demo\\client" +
                "\\getNotes.json");

        ObjectMapper objectMapper = new ObjectMapper();
        NotesRoot notesRoot = null;
        try {
            notesRoot = objectMapper.readValue(new FileInputStream(file), NotesRoot.class);

        } catch (IOException e) {
            e.printStackTrace();
        }

        return notesRoot;

    }
}
