package com.example.H2.Repository;

import com.example.H2.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public class ItemRepository{


    @Autowired
    JdbcTemplate template;

    /*Getting all Items from table*/
    public List<Product> getAllItems() {
        List<Product> items = template.query("select id, name,category from item", (result, rowNum) -> new Product(result.getInt("id"),
                result.getString("name"), result.getString("category")));
        return items;
    }

    /*Getting a specific item by item id from table*/
    public Product getItem(int itemId) {
        String query = "SELECT * FROM PRODUCTS WHERE ID=?";
        Product products = template.queryForObject(query, new Object[]{itemId}, new BeanPropertyRowMapper<>(Product.class));

        return products;
    }

    /*Adding an item into database table*/
    public int addItem(int id, String name, String category) {
        String query = "INSERT INTO PRODUCTS VALUES(?,?,?)";
        return template.update(query, id, name, category);
    }

    /*delete an item from database*/
    public int deleteItem(int id) {
        String query = "DELETE FROM PRODUCTS WHERE ID =?";
        return template.update(query, id);
    }
}

