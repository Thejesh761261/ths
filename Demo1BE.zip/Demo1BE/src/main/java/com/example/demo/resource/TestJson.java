package com.example.demo.resource;


import java.util.List;

public class TestJson {

    private String var1;

    private String var2;

    private List<String> listStr;

    private TestJsonOne testJsonOne;

    public List<String> getListStr() {
        return listStr;
    }

    public void setListStr(List<String> listStr) {
        this.listStr = listStr;
    }

    public TestJsonOne getTestJsonOne() {
        return testJsonOne;
    }

    public void setTestJsonOne(TestJsonOne testJsonOne) {
        this.testJsonOne = testJsonOne;
    }

    public String getVar1() {
        return var1;
    }

    public void setVar1(String var1) {
        this.var1 = var1;
    }

    public String getVar2() {
        return var2;
    }

    public void setVar2(String var2) {
        this.var2 = var2;
    }
}
