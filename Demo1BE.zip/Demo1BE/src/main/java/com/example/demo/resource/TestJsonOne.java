package com.example.demo.resource;

import java.util.Map;

public class TestJsonOne {

    private String var1;

    private Map var2;

    public String getVar1() {
        return var1;
    }

    public void setVar1(String var1) {
        this.var1 = var1;
    }

    public Map getVar2() {
        return var2;
    }

    public void setVar2(Map var2) {
        this.var2 = var2;
    }
}
