package com.example.demo.service.ServiceImpl;

import com.example.demo.client.ClientServiceImpl;
import com.example.demo.client.model.Note;
import com.example.demo.client.model.Notes;
import com.example.demo.client.model.NotesRootClientResponse;
import com.example.demo.resource.model.EmailRecord;
import com.example.demo.resource.model.NotesRoot;
import com.example.demo.service.NotesService;
import com.example.demo.service.UserClient;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class NotesServiceImpl implements NotesService {

    @Autowired
    ClientServiceImpl clientService;

    @Autowired
    UserClient userClient;
  //@HystrixCommand(fallbackMethod = "defaultGetTestData")
    public NotesRoot getNotes(final String reservationNumber){

        NotesRootClientResponse notesRootClientResponse=clientService.getNotes(reservationNumber);

        com.example.demo.resource.model.Notes notes1=new com.example.demo.resource.model.Notes();
        NotesRoot notesRoot=new NotesRoot();

        Notes clientNotes=notesRootClientResponse.getNotes();
        List<Note> noteList=clientNotes.getNote();

        List<com.example.demo.resource.model.Note> resourceNotes=new ArrayList<>();

        for(Note note:noteList)
        {
            com.example.demo.resource.model.Note resourceNote=new com.example.demo.resource.model.Note();
            //resourceNote.setAssociateDivision(note.getAssociateDivision());
            //resourceNotes.add(resourceNote);
            BeanUtils.copyProperties(note,resourceNote);

            if(note.getEmailRecord()!=null) {
                EmailRecord emailRecord=new EmailRecord();
               /* emailRecord.setDeliveryStatus(note.getEmailRecord().getDeliveryStatus());
                emailRecord.setDeliveryType(note.getEmailRecord().getDeliveryType());
                emailRecord.setEmailAddress(note.getEmailRecord().getEmailAddress());
                emailRecord.setEmailAddress(note.getEmailRecord().getMailId());
                emailRecord.setTransmitTimestamp(note.getEmailRecord().getTransmitTimestamp());
                */
                BeanUtils.copyProperties(note.getEmailRecord(),emailRecord);
                resourceNote.setEmailRecord(emailRecord);
            }

            resourceNotes.add(resourceNote);

        }
        notes1.setNote(resourceNotes);
        notesRoot.setNotes(notes1);
        return notesRoot;
    }

   /*public String defaultGetTestData(){
        System.out.println("*******************************************");
        return  "fallback method executed from NotesService";
    }*/


}
