package com.example.demo.service;

import com.example.demo.client.model.NotesRootClientResponse;
import com.example.demo.resource.model.Notes;
import com.example.demo.resource.model.NotesRoot;
import com.example.demo.resource.model.SpecialistsList;
import com.example.demo.resource.model.SpecialistsResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UserClient {

    @Bean
    private RestTemplate getRestTemplate(){ return new RestTemplate();}


    @HystrixCommand(fallbackMethod = "defaultGetTestData")
    public String getTestData(String name,String type){

        String specialistsResponse = getRestTemplate().getForObject("http://localhost:9150/specialists/"+name+"/"+type,
                String.class);

        return specialistsResponse;


        /*NotesRoot notes=null;

        try{
            File file=new File("C:\\Thejesh\\demo1\\src\\main\\java\\com\\example\\demo\\service\\getNotes.json");
            ObjectMapper mapper=new ObjectMapper();
            notes = mapper.readValue(new FileInputStream(file),NotesRoot.class);

        }catch (Exception e)
        {
            e.printStackTrace();
        }*/

    }

    public String defaultGetTestData(String a,String b){
        System.out.println("*******************************************");
       //return  "fallback method executed";
        return null;
    }

    public NotesRoot notesConversion(NotesRootClientResponse notes) {

        NotesRoot notesRoot=new NotesRoot();

       return  notesRoot;
    }
}
