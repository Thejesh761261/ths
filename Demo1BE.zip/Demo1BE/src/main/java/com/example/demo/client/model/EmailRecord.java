package com.example.demo.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmailRecord {

    private String transmitTimestamp;
    private String deliveryStatus;
    private String deliveryType;
    private String mailId;
    private String emailAddress;


    public String getTransmitTimestamp() {
        return transmitTimestamp;
    }

    public void setTransmitTimestamp(String transmitTimestamp) {
        this.transmitTimestamp = transmitTimestamp;
    }

    public String getDeliveryStatus() {
        return deliveryStatus;
    }

    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    public String getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType;
    }

    public String getMailId() {
        return mailId;
    }

    public void setMailId(String mailId) {
        this.mailId = mailId;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

}