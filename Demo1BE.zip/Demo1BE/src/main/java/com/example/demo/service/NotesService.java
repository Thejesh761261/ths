package com.example.demo.service;

import com.example.demo.resource.model.NotesRoot;

public interface NotesService {

NotesRoot getNotes(final String reservationNumber);
}
