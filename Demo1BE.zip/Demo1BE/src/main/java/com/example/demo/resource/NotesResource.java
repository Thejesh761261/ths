package com.example.demo.resource;

import com.example.demo.resource.model.NotesRoot;
import com.example.demo.service.NotesService;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NotesResource {

    @Autowired
    NotesService notesService;

    @GetMapping("/reservation-number/{reservationNumber}/notes")
    @Produces(MediaType.APPLICATION_JSON)
    public NotesRoot returnNotes(@PathVariable final String reservationNumber) {

        NotesRoot notes = notesService.getNotes(reservationNumber);

        return notes;
    }

}
