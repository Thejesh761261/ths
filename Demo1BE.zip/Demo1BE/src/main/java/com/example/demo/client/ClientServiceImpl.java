package com.example.demo.client;

import com.example.demo.client.model.NotesRootClientResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.FileInputStream;
import org.springframework.stereotype.Service;

@Service
public class ClientServiceImpl {

    public NotesRootClientResponse getNotes(final String reservationNumber){

        NotesRootClientResponse notes=null;

        try{
            File file=new File("C:\\Thejesh\\demo1\\src\\main\\java\\com\\example\\demo\\service\\getNotes.json");
            ObjectMapper mapper=new ObjectMapper();
            notes = mapper.readValue(new FileInputStream(file),NotesRootClientResponse.class);

        }catch (Exception e)
        {
            e.printStackTrace();
        }

        return notes;
    }
}
