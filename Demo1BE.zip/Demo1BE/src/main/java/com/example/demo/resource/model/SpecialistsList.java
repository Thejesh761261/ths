package com.example.demo.resource.model;

import java.util.List;

public class SpecialistsList {

    private List<SpecialistsResponse> specialistsResponses;

    public List<SpecialistsResponse> getSpecialistsResponses() {
        return specialistsResponses;
    }

    public void setSpecialistsResponses(List<SpecialistsResponse> specialistsResponses) {
        this.specialistsResponses = specialistsResponses;
    }

    public SpecialistsList() {
    }

    public SpecialistsList(List<SpecialistsResponse> specialistsResponses) {
        this.specialistsResponses = specialistsResponses;
    }

    @Override
    public String toString() {
        return "SpecialistsList{" +
                "specialistsResponses=" + specialistsResponses +
                '}';
    }
}
