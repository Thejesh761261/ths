package com.example.demo.resource;

import com.example.demo.resource.model.SpecialistsResponse;
import com.example.demo.service.UserClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestHystrix {

    @Autowired
    private UserClient userClient;

    @GetMapping(value = "/getGreeting/{name}/{type}", produces = {MediaType.APPLICATION_JSON_VALUE,
            MediaType.APPLICATION_XML_VALUE})
    public String getGreeting(@PathVariable("name")final String name, @PathVariable("type")final String type) {
        String specialistsResponse = userClient.getTestData(name, type);
        return specialistsResponse;
    }

    @GetMapping("/hai")
    public String hai() {
        return "Hi Thejesh";
    }

   /* @GetMapping("/getSpecialists/{name}/{type}")
    public String getSpecialists(@PathVariable("name") String name,@PathVariable("type") String type,Model model)
    {
        String specialistsResponse = userClient.getTestData(name,type);
        return specialistsResponse;
    }*/

}
