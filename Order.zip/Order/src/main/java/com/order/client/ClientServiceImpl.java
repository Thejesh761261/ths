package com.order.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.order.client.model.ShipmentInfo;
import java.io.File;
import java.io.FileInputStream;
import org.springframework.stereotype.Service;

@Service
public class ClientServiceImpl {
    public ShipmentInfo getOrder() {

        ShipmentInfo shipmentInfo=null;
        try{
            File file=new File("C:\\Thejesh\\order\\src\\main\\java\\com\\order\\service\\shipment.json");
            ObjectMapper mapper=new ObjectMapper();
            shipmentInfo = mapper.readValue(new FileInputStream(file),ShipmentInfo.class);

        }catch (Exception e)
        {
            e.printStackTrace();
        }

        return shipmentInfo;
    }
}
