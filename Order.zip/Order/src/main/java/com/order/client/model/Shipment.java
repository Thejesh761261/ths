package com.order.client.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Shipment {

    private Boolean replacementShipment;
    private Boolean allPickupShipmentsReady;
    private GiftMessage giftMessage;
    private String total;
    private Boolean virtualReturnShipment;
    private String dropshipVendorNumber;
    private String creditedAmount;
    private String returnPickupFlag;
    private String poNumber;
    private String shippingFee;
    private String surchargeFee;
    private String giftWrapFee;
    private String totalTaxes;
    private String merchandiseTotal;
    private Registry registry;
    private String shipmentStatusDescription;
    private List<Item> items = null;
    private List<Tracking> trackings = null;
    private Contact contact;
    private Boolean isVGCShipment;
    private String shipmentStatusDate;
    private String shippingMethod;
    private String shipmentStatusCode;
    private String shipmentTrackingStatus;
    private String expectedDeliveryDate;
    private Boolean isVirtualShipmentInTransit;
    private String shipmentType;
    private Boolean showTrackMyReturn;
    private Boolean shipToRegistry;
    private String salesCheckNumber;
    private String sortIdentifier;
    private Boolean militaryReturnFlag;
    private String giftWrapType;
    private Boolean virtualReturnFlag;
    private Boolean shipmentTrackingEnabled;


    public Boolean getReplacementShipment() {
        return replacementShipment;
    }

    public void setReplacementShipment(Boolean replacementShipment) {
        this.replacementShipment = replacementShipment;
    }

    public Boolean getAllPickupShipmentsReady() {
        return allPickupShipmentsReady;
    }

    public void setAllPickupShipmentsReady(Boolean allPickupShipmentsReady) {
        this.allPickupShipmentsReady = allPickupShipmentsReady;
    }

    public GiftMessage getGiftMessage() {
        return giftMessage;
    }

    public void setGiftMessage(GiftMessage giftMessage) {
        this.giftMessage = giftMessage;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public Boolean getVirtualReturnShipment() {
        return virtualReturnShipment;
    }

    public void setVirtualReturnShipment(Boolean virtualReturnShipment) {
        this.virtualReturnShipment = virtualReturnShipment;
    }

    public String getDropshipVendorNumber() {
        return dropshipVendorNumber;
    }

    public void setDropshipVendorNumber(String dropshipVendorNumber) {
        this.dropshipVendorNumber = dropshipVendorNumber;
    }

    public String getCreditedAmount() {
        return creditedAmount;
    }

    public void setCreditedAmount(String creditedAmount) {
        this.creditedAmount = creditedAmount;
    }

    public String getReturnPickupFlag() {
        return returnPickupFlag;
    }

    public void setReturnPickupFlag(String returnPickupFlag) {
        this.returnPickupFlag = returnPickupFlag;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public String getShippingFee() {
        return shippingFee;
    }

    public void setShippingFee(String shippingFee) {
        this.shippingFee = shippingFee;
    }

    public String getSurchargeFee() {
        return surchargeFee;
    }

    public void setSurchargeFee(String surchargeFee) {
        this.surchargeFee = surchargeFee;
    }

    public String getGiftWrapFee() {
        return giftWrapFee;
    }

    public void setGiftWrapFee(String giftWrapFee) {
        this.giftWrapFee = giftWrapFee;
    }

    public String getTotalTaxes() {
        return totalTaxes;
    }

    public void setTotalTaxes(String totalTaxes) {
        this.totalTaxes = totalTaxes;
    }

    public String getMerchandiseTotal() {
        return merchandiseTotal;
    }

    public void setMerchandiseTotal(String merchandiseTotal) {
        this.merchandiseTotal = merchandiseTotal;
    }

    public Registry getRegistry() {
        return registry;
    }

    public void setRegistry(Registry registry) {
        this.registry = registry;
    }

    public String getShipmentStatusDescription() {
        return shipmentStatusDescription;
    }

    public void setShipmentStatusDescription(String shipmentStatusDescription) {
        this.shipmentStatusDescription = shipmentStatusDescription;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public List<Tracking> getTrackings() {
        return trackings;
    }

    public void setTrackings(List<Tracking> trackings) {
        this.trackings = trackings;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public Boolean getIsVGCShipment() {
        return isVGCShipment;
    }

    public void setIsVGCShipment(Boolean isVGCShipment) {
        this.isVGCShipment = isVGCShipment;
    }

    public String getShipmentStatusDate() {
        return shipmentStatusDate;
    }

    public void setShipmentStatusDate(String shipmentStatusDate) {
        this.shipmentStatusDate = shipmentStatusDate;
    }

    public String getShippingMethod() {
        return shippingMethod;
    }

    public void setShippingMethod(String shippingMethod) {
        this.shippingMethod = shippingMethod;
    }

    public String getShipmentStatusCode() {
        return shipmentStatusCode;
    }

    public void setShipmentStatusCode(String shipmentStatusCode) {
        this.shipmentStatusCode = shipmentStatusCode;
    }

    public String getShipmentTrackingStatus() {
        return shipmentTrackingStatus;
    }

    public void setShipmentTrackingStatus(String shipmentTrackingStatus) {
        this.shipmentTrackingStatus = shipmentTrackingStatus;
    }

    public String getExpectedDeliveryDate() {
        return expectedDeliveryDate;
    }

    public void setExpectedDeliveryDate(String expectedDeliveryDate) {
        this.expectedDeliveryDate = expectedDeliveryDate;
    }

    public Boolean getIsVirtualShipmentInTransit() {
        return isVirtualShipmentInTransit;
    }

    public void setIsVirtualShipmentInTransit(Boolean isVirtualShipmentInTransit) {
        this.isVirtualShipmentInTransit = isVirtualShipmentInTransit;
    }

    public String getShipmentType() {
        return shipmentType;
    }

    public void setShipmentType(String shipmentType) {
        this.shipmentType = shipmentType;
    }

    public Boolean getShowTrackMyReturn() {
        return showTrackMyReturn;
    }

    public void setShowTrackMyReturn(Boolean showTrackMyReturn) {
        this.showTrackMyReturn = showTrackMyReturn;
    }

    public Boolean getShipToRegistry() {
        return shipToRegistry;
    }

    public void setShipToRegistry(Boolean shipToRegistry) {
        this.shipToRegistry = shipToRegistry;
    }

    public String getSalesCheckNumber() {
        return salesCheckNumber;
    }

    public void setSalesCheckNumber(String salesCheckNumber) {
        this.salesCheckNumber = salesCheckNumber;
    }

    public String getSortIdentifier() {
        return sortIdentifier;
    }

    public void setSortIdentifier(String sortIdentifier) {
        this.sortIdentifier = sortIdentifier;
    }

    public Boolean getMilitaryReturnFlag() {
        return militaryReturnFlag;
    }

    public void setMilitaryReturnFlag(Boolean militaryReturnFlag) {
        this.militaryReturnFlag = militaryReturnFlag;
    }

    public String getGiftWrapType() {
        return giftWrapType;
    }

    public void setGiftWrapType(String giftWrapType) {
        this.giftWrapType = giftWrapType;
    }

    public Boolean getVirtualReturnFlag() {
        return virtualReturnFlag;
    }

    public void setVirtualReturnFlag(Boolean virtualReturnFlag) {
        this.virtualReturnFlag = virtualReturnFlag;
    }

    public Boolean getShipmentTrackingEnabled() {
        return shipmentTrackingEnabled;
    }

    public void setShipmentTrackingEnabled(Boolean shipmentTrackingEnabled) {
        this.shipmentTrackingEnabled = shipmentTrackingEnabled;
    }

}
