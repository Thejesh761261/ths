
package com.order.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class Detail {

    private String name;
    private String brand;
    private String gmm;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getGmm() {
        return gmm;
    }

    public void setGmm(String gmm) {
        this.gmm = gmm;
    }

}
