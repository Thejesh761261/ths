package com.order.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Item {

    private Boolean beautyBoxProduct;
    private Boolean inTransit;
    private Integer financialDivisionNumber;
    private Integer storeNumber;
    private Integer transactionNumber;
    private Integer lineNumber;
    private Integer shipmentNumber;
    private Long upc;
    private String soldPrice;
    private Integer itemQuantity;
    private Boolean lastActIndicator;
    private Boolean outletSaleIndicator;
    private String itemTotal;
    private String total;
    private String tax;
    private Integer departmentNumber;
    private Integer merchandiseDepartmentClassNumber;
    private String itemDescription;
    private Integer colorNumber;
    private String colorDescription;
    private String sizeNumber;
    private String sizeDescription;
    private Integer markStyleNumber;
    private Integer vendorNumber;
    private String vendorName;
    private String uycTotalDiscountedPrice;
    private String uycDiscountedPercentage;
    private String currentTax;
    private String eligibleForPreOrder;
    private String originalQuantity;
    private Integer returnQuantity;
    private String uycPercentDiscount;
    private String shopRunnerEligible;
    private String currentPrice;
    private Integer returnPendingQuantity;
    private String surchargeFee;
    private String personalizationFee;
    private String originalPrice;
    private Integer currentQuantity;
    private String logicalShipmentNumber;
    private String icwEligible;
    private Integer upcId;
    private Boolean reBuyEligibleFlag;
    private Product product;
    private String status;
    private String giftWrapType;
    private String statusCode;
    private String expectedShipDate;
    private Boolean isCanceled;
    private String virtualReturnStatus;
    private String mosFlag;
    private Boolean isVirtualReturnPending;
    private FulfillmentInfo fulfillmentInfo;
    private Integer xRefLineNumber;
    private String statusDate;
    private Boolean itemSelected;
    private Boolean enableQV;
    private Boolean enableReview;
    private Integer selectedQuantity;
    private Boolean returnEligibleFlag;
    private Boolean blockedVendorFlag;
    private String returnWindowDate;
    private Integer returnEligibilityDaysOverdue;
    private Integer returnPolicyDays;

    public Boolean getBeautyBoxProduct() {
        return beautyBoxProduct;
    }

    public void setBeautyBoxProduct(Boolean beautyBoxProduct) {
        this.beautyBoxProduct = beautyBoxProduct;
    }

    public Boolean getInTransit() {
        return inTransit;
    }

    public void setInTransit(Boolean inTransit) {
        this.inTransit = inTransit;
    }

    public Integer getFinancialDivisionNumber() {
        return financialDivisionNumber;
    }

    public void setFinancialDivisionNumber(Integer financialDivisionNumber) {
        this.financialDivisionNumber = financialDivisionNumber;
    }

    public Integer getStoreNumber() {
        return storeNumber;
    }

    public void setStoreNumber(Integer storeNumber) {
        this.storeNumber = storeNumber;
    }

    public Integer getTransactionNumber() {
        return transactionNumber;
    }

    public void setTransactionNumber(Integer transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public Integer getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(Integer lineNumber) {
        this.lineNumber = lineNumber;
    }

    public Integer getShipmentNumber() {
        return shipmentNumber;
    }

    public void setShipmentNumber(Integer shipmentNumber) {
        this.shipmentNumber = shipmentNumber;
    }

    public Long getUpc() {
        return upc;
    }

    public void setUpc(Long upc) {
        this.upc = upc;
    }

    public String getSoldPrice() {
        return soldPrice;
    }

    public void setSoldPrice(String soldPrice) {
        this.soldPrice = soldPrice;
    }

    public Integer getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(Integer itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public Boolean getLastActIndicator() {
        return lastActIndicator;
    }

    public void setLastActIndicator(Boolean lastActIndicator) {
        this.lastActIndicator = lastActIndicator;
    }

    public Boolean getOutletSaleIndicator() {
        return outletSaleIndicator;
    }

    public void setOutletSaleIndicator(Boolean outletSaleIndicator) {
        this.outletSaleIndicator = outletSaleIndicator;
    }

    public String getItemTotal() {
        return itemTotal;
    }

    public void setItemTotal(String itemTotal) {
        this.itemTotal = itemTotal;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getTax() {
        return tax;
    }

    public void setTax(String tax) {
        this.tax = tax;
    }

    public Integer getDepartmentNumber() {
        return departmentNumber;
    }

    public void setDepartmentNumber(Integer departmentNumber) {
        this.departmentNumber = departmentNumber;
    }

    public Integer getMerchandiseDepartmentClassNumber() {
        return merchandiseDepartmentClassNumber;
    }

    public void setMerchandiseDepartmentClassNumber(Integer merchandiseDepartmentClassNumber) {
        this.merchandiseDepartmentClassNumber = merchandiseDepartmentClassNumber;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public Integer getColorNumber() {
        return colorNumber;
    }

    public void setColorNumber(Integer colorNumber) {
        this.colorNumber = colorNumber;
    }

    public String getColorDescription() {
        return colorDescription;
    }

    public void setColorDescription(String colorDescription) {
        this.colorDescription = colorDescription;
    }

    public String getSizeNumber() {
        return sizeNumber;
    }

    public void setSizeNumber(String sizeNumber) {
        this.sizeNumber = sizeNumber;
    }

    public String getSizeDescription() {
        return sizeDescription;
    }

    public void setSizeDescription(String sizeDescription) {
        this.sizeDescription = sizeDescription;
    }

    public Integer getMarkStyleNumber() {
        return markStyleNumber;
    }

    public void setMarkStyleNumber(Integer markStyleNumber) {
        this.markStyleNumber = markStyleNumber;
    }

    public Integer getVendorNumber() {
        return vendorNumber;
    }

    public void setVendorNumber(Integer vendorNumber) {
        this.vendorNumber = vendorNumber;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getUycTotalDiscountedPrice() {
        return uycTotalDiscountedPrice;
    }

    public void setUycTotalDiscountedPrice(String uycTotalDiscountedPrice) {
        this.uycTotalDiscountedPrice = uycTotalDiscountedPrice;
    }

    public String getUycDiscountedPercentage() {
        return uycDiscountedPercentage;
    }

    public void setUycDiscountedPercentage(String uycDiscountedPercentage) {
        this.uycDiscountedPercentage = uycDiscountedPercentage;
    }

    public String getCurrentTax() {
        return currentTax;
    }

    public void setCurrentTax(String currentTax) {
        this.currentTax = currentTax;
    }

    public String getEligibleForPreOrder() {
        return eligibleForPreOrder;
    }

    public void setEligibleForPreOrder(String eligibleForPreOrder) {
        this.eligibleForPreOrder = eligibleForPreOrder;
    }

    public String getOriginalQuantity() {
        return originalQuantity;
    }

    public void setOriginalQuantity(String originalQuantity) {
        this.originalQuantity = originalQuantity;
    }

    public Integer getReturnQuantity() {
        return returnQuantity;
    }

    public void setReturnQuantity(Integer returnQuantity) {
        this.returnQuantity = returnQuantity;
    }

    public String getUycPercentDiscount() {
        return uycPercentDiscount;
    }

    public void setUycPercentDiscount(String uycPercentDiscount) {
        this.uycPercentDiscount = uycPercentDiscount;
    }

    public String getShopRunnerEligible() {
        return shopRunnerEligible;
    }

    public void setShopRunnerEligible(String shopRunnerEligible) {
        this.shopRunnerEligible = shopRunnerEligible;
    }

    public String getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(String currentPrice) {
        this.currentPrice = currentPrice;
    }

    public Integer getReturnPendingQuantity() {
        return returnPendingQuantity;
    }

    public void setReturnPendingQuantity(Integer returnPendingQuantity) {
        this.returnPendingQuantity = returnPendingQuantity;
    }

    public String getSurchargeFee() {
        return surchargeFee;
    }

    public void setSurchargeFee(String surchargeFee) {
        this.surchargeFee = surchargeFee;
    }

    public String getPersonalizationFee() {
        return personalizationFee;
    }

    public void setPersonalizationFee(String personalizationFee) {
        this.personalizationFee = personalizationFee;
    }

    public String getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(String originalPrice) {
        this.originalPrice = originalPrice;
    }

    public Integer getCurrentQuantity() {
        return currentQuantity;
    }

    public void setCurrentQuantity(Integer currentQuantity) {
        this.currentQuantity = currentQuantity;
    }

    public String getLogicalShipmentNumber() {
        return logicalShipmentNumber;
    }

    public void setLogicalShipmentNumber(String logicalShipmentNumber) {
        this.logicalShipmentNumber = logicalShipmentNumber;
    }

    public String getIcwEligible() {
        return icwEligible;
    }

    public void setIcwEligible(String icwEligible) {
        this.icwEligible = icwEligible;
    }

    public Integer getUpcId() {
        return upcId;
    }

    public void setUpcId(Integer upcId) {
        this.upcId = upcId;
    }

    public Boolean getReBuyEligibleFlag() {
        return reBuyEligibleFlag;
    }

    public void setReBuyEligibleFlag(Boolean reBuyEligibleFlag) {
        this.reBuyEligibleFlag = reBuyEligibleFlag;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getGiftWrapType() {
        return giftWrapType;
    }

    public void setGiftWrapType(String giftWrapType) {
        this.giftWrapType = giftWrapType;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getExpectedShipDate() {
        return expectedShipDate;
    }

    public void setExpectedShipDate(String expectedShipDate) {
        this.expectedShipDate = expectedShipDate;
    }

    public Boolean getIsCanceled() {
        return isCanceled;
    }

    public void setIsCanceled(Boolean isCanceled) {
        this.isCanceled = isCanceled;
    }

    public String getVirtualReturnStatus() {
        return virtualReturnStatus;
    }

    public void setVirtualReturnStatus(String virtualReturnStatus) {
        this.virtualReturnStatus = virtualReturnStatus;
    }

    public String getMosFlag() {
        return mosFlag;
    }

    public void setMosFlag(String mosFlag) {
        this.mosFlag = mosFlag;
    }

    public Boolean getIsVirtualReturnPending() {
        return isVirtualReturnPending;
    }

    public void setIsVirtualReturnPending(Boolean isVirtualReturnPending) {
        this.isVirtualReturnPending = isVirtualReturnPending;
    }

    public FulfillmentInfo getFulfillmentInfo() {
        return fulfillmentInfo;
    }

    public void setFulfillmentInfo(FulfillmentInfo fulfillmentInfo) {
        this.fulfillmentInfo = fulfillmentInfo;
    }

    public Integer getxRefLineNumber() {
        return xRefLineNumber;
    }

    public void setxRefLineNumber(Integer xRefLineNumber) {
        this.xRefLineNumber = xRefLineNumber;
    }

    public String getStatusDate() {
        return statusDate;
    }

    public void setStatusDate(String statusDate) {
        this.statusDate = statusDate;
    }

    public Boolean getItemSelected() {
        return itemSelected;
    }

    public void setItemSelected(Boolean itemSelected) {
        this.itemSelected = itemSelected;
    }

    public Boolean getEnableQV() {
        return enableQV;
    }

    public void setEnableQV(Boolean enableQV) {
        this.enableQV = enableQV;
    }

    public Boolean getEnableReview() {
        return enableReview;
    }

    public void setEnableReview(Boolean enableReview) {
        this.enableReview = enableReview;
    }

    public Integer getSelectedQuantity() {
        return selectedQuantity;
    }

    public void setSelectedQuantity(Integer selectedQuantity) {
        this.selectedQuantity = selectedQuantity;
    }

    public Boolean getReturnEligibleFlag() {
        return returnEligibleFlag;
    }

    public void setReturnEligibleFlag(Boolean returnEligibleFlag) {
        this.returnEligibleFlag = returnEligibleFlag;
    }

    public Boolean getBlockedVendorFlag() {
        return blockedVendorFlag;
    }

    public void setBlockedVendorFlag(Boolean blockedVendorFlag) {
        this.blockedVendorFlag = blockedVendorFlag;
    }

    public String getReturnWindowDate() {
        return returnWindowDate;
    }

    public void setReturnWindowDate(String returnWindowDate) {
        this.returnWindowDate = returnWindowDate;
    }

    public Integer getReturnEligibilityDaysOverdue() {
        return returnEligibilityDaysOverdue;
    }

    public void setReturnEligibilityDaysOverdue(Integer returnEligibilityDaysOverdue) {
        this.returnEligibilityDaysOverdue = returnEligibilityDaysOverdue;
    }

    public Integer getReturnPolicyDays() {
        return returnPolicyDays;
    }

    public void setReturnPolicyDays(Integer returnPolicyDays) {
        this.returnPolicyDays = returnPolicyDays;
    }


}
