
package com.order.client.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class Tracking {

    private String actualDeliveryTimestamp;
    private String carrierName;
    private String expectedDeliveryDate;
    private String trackingNumber;
    private List<TrackingEventList> trackingEventList = null;
    private String trackingURL;
    private String trackingEventStatus;
    private String receivedAt;

    public String getActualDeliveryTimestamp() {
        return actualDeliveryTimestamp;
    }

    public void setActualDeliveryTimestamp(String actualDeliveryTimestamp) {
        this.actualDeliveryTimestamp = actualDeliveryTimestamp;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getExpectedDeliveryDate() {
        return expectedDeliveryDate;
    }

    public void setExpectedDeliveryDate(String expectedDeliveryDate) {
        this.expectedDeliveryDate = expectedDeliveryDate;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public List<TrackingEventList> getTrackingEventList() {
        return trackingEventList;
    }

    public void setTrackingEventList(List<TrackingEventList> trackingEventList) {
        this.trackingEventList = trackingEventList;
    }

    public String getTrackingURL() {
        return trackingURL;
    }

    public void setTrackingURL(String trackingURL) {
        this.trackingURL = trackingURL;
    }

    public String getTrackingEventStatus() {
        return trackingEventStatus;
    }

    public void setTrackingEventStatus(String trackingEventStatus) {
        this.trackingEventStatus = trackingEventStatus;
    }

    public String getReceivedAt() {
        return receivedAt;
    }

    public void setReceivedAt(String receivedAt) {
        this.receivedAt = receivedAt;
    }

}
