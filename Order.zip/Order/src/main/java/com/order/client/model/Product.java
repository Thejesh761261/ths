
package com.order.client.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class Product {

    private String id;
    private Imagery imagery;
    private Detail detail;
    private List<Price> price = null;
    private Traits traits;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Imagery getImagery() {
        return imagery;
    }

    public void setImagery(Imagery imagery) {
        this.imagery = imagery;
    }

    public Detail getDetail() {
        return detail;
    }

    public void setDetail(Detail detail) {
        this.detail = detail;
    }

    public List<Price> getPrice() {
        return price;
    }

    public void setPrice(List<Price> price) {
        this.price = price;
    }

    public Traits getTraits() {
        return traits;
    }

    public void setTraits(Traits traits) {
        this.traits = traits;
    }


}
