
package com.order.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FulfillmentInfo {

    private String dropshipDeliveryMethod;
    private Integer fillDivisionNumber;
    private String fillLocationName;
    private Integer fillStoreNumber;
    private String orderMethod;


    public String getDropshipDeliveryMethod() {
        return dropshipDeliveryMethod;
    }

    public void setDropshipDeliveryMethod(String dropshipDeliveryMethod) {
        this.dropshipDeliveryMethod = dropshipDeliveryMethod;
    }

    public Integer getFillDivisionNumber() {
        return fillDivisionNumber;
    }

    public void setFillDivisionNumber(Integer fillDivisionNumber) {
        this.fillDivisionNumber = fillDivisionNumber;
    }

    public String getFillLocationName() {
        return fillLocationName;
    }

    public void setFillLocationName(String fillLocationName) {
        this.fillLocationName = fillLocationName;
    }

    public Integer getFillStoreNumber() {
        return fillStoreNumber;
    }

    public void setFillStoreNumber(Integer fillStoreNumber) {
        this.fillStoreNumber = fillStoreNumber;
    }

    public String getOrderMethod() {
        return orderMethod;
    }

    public void setOrderMethod(String orderMethod) {
        this.orderMethod = orderMethod;
    }

}
