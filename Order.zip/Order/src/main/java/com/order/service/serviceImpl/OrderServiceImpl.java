package com.order.service.serviceImpl;

import com.order.client.ClientServiceImpl;
import com.order.client.model.Order;
import com.order.client.model.Shipment;
import com.order.client.model.ShipmentInfo;
import com.order.client.model.Tracking;
import com.order.client.model.TrackingEventList;
import com.order.client.model.TrackingEventLoc;
import com.order.resource.model.TrackingEventListResourceResponse;
import com.order.resource.model.TrackingEventLocResourceResponse;
import com.order.resource.model.TrackingResourceReponse;
import com.order.service.OrderService;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    ClientServiceImpl clientService;

    @Override
    public TrackingResourceReponse getOrder() {
      ShipmentInfo shipmentInfo= clientService.getOrder();
        Order order=shipmentInfo.getOrder();
        List<Shipment> shipmentList=order.getShipments();
        TrackingResourceReponse trackingResourceReponse=new TrackingResourceReponse();

        for(Shipment shipment:shipmentList)
        {
            List<Tracking> trackingList=shipment.getTrackings();

            for(Tracking tracking:trackingList)
            {
                List<TrackingResourceReponse> trackingResourceReponses= new ArrayList<>();

                BeanUtils.copyProperties(tracking,trackingResourceReponse);

                List<TrackingEventList> trackingEventLists=tracking.getTrackingEventList();
                for(TrackingEventList trackingEventList:trackingEventLists)
                {
                    List<TrackingEventListResourceResponse> trackingEventListResourceResponses=new ArrayList<>();
                    TrackingEventListResourceResponse trackingEventListResourceResponse=
                            new TrackingEventListResourceResponse();

                    trackingEventListResourceResponse.setTrackingEventDetails(trackingEventList.getTrackingEventDetails());
                    trackingEventListResourceResponse.setTrackingEventTime(trackingEventList.getTrackingEventTime());
                    trackingEventListResourceResponse.setTrackingEventStatus(trackingEventList.getTrackingEventStatus());
                    trackingEventListResourceResponse.setTrackingEventDate(trackingEventList.getTrackingEventDate());
                    trackingEventListResourceResponse.setTrackingEventTimestamp(trackingEventList.getTrackingEventTimestamp());

                    TrackingEventLoc trackingEventLoc=trackingEventList.getTrackingEventLoc();
                    TrackingEventLocResourceResponse trackingEventLocResourceResponse=
                            new TrackingEventLocResourceResponse();

                    trackingEventLocResourceResponse.setTrackingEventZipCode(trackingEventLoc.getTrackingEventZipCode());
                    trackingEventLocResourceResponse.setTrackingEventState(trackingEventLoc.getTrackingEventState());
                    trackingEventLocResourceResponse.setTrackingEventCountry(trackingEventLoc.getTrackingEventCountry());
                    trackingEventLocResourceResponse.setTrackingEventCity(trackingEventLoc.getTrackingEventCity());
                    trackingEventListResourceResponse.setTrackingEventLoc(trackingEventLocResourceResponse);
                    trackingEventListResourceResponses.add(trackingEventListResourceResponse);
                }
                trackingResourceReponses.add(trackingResourceReponse);
            }
        }
        return trackingResourceReponse;
    }
}
