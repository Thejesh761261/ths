package com.order.service;

import com.order.resource.model.TrackingResourceReponse;

public interface OrderService {
    TrackingResourceReponse getOrder();

}
