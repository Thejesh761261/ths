
package com.order.resource.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonRootName("trackings")
public class TrackingResourceReponse {

    private String actualDeliveryTimestamp;
    private String carrierName;
    private String expectedDeliveryDate;
    private String trackingNumber;
    private List<TrackingEventListResourceResponse> trackingEventList = null;
    private String trackingURL;
    private String trackingEventStatus;
    private String receivedAt;

    public String getActualDeliveryTimestamp() {
        return actualDeliveryTimestamp;
    }

    public void setActualDeliveryTimestamp(String actualDeliveryTimestamp) {
        this.actualDeliveryTimestamp = actualDeliveryTimestamp;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getExpectedDeliveryDate() {
        return expectedDeliveryDate;
    }

    public void setExpectedDeliveryDate(String expectedDeliveryDate) {
        this.expectedDeliveryDate = expectedDeliveryDate;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public List<TrackingEventListResourceResponse> getTrackingEventList() {
        return trackingEventList;
    }

    public void setTrackingEventList(List<TrackingEventListResourceResponse> trackingEventList) {
        this.trackingEventList = trackingEventList;
    }

    public String getTrackingURL() {
        return trackingURL;
    }

    public void setTrackingURL(String trackingURL) {
        this.trackingURL = trackingURL;
    }

    public String getTrackingEventStatus() {
        return trackingEventStatus;
    }

    public void setTrackingEventStatus(String trackingEventStatus) {
        this.trackingEventStatus = trackingEventStatus;
    }

    public String getReceivedAt() {
        return receivedAt;
    }

    public void setReceivedAt(String receivedAt) {
        this.receivedAt = receivedAt;
    }

}
