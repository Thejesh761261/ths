package com.order.resource;

import com.order.client.ClientServiceImpl;
import com.order.client.model.ShipmentInfo;
import com.order.resource.model.TrackingResourceReponse;
import com.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrederResource {

    @Autowired
    OrderService orderService;

    @GetMapping("/getOrder")
    public TrackingResourceReponse returnNotes() {
        TrackingResourceReponse cimpl=orderService.getOrder();
        return cimpl;
    }

}
