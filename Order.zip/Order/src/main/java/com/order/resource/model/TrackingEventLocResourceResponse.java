
package com.order.resource.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TrackingEventLocResourceResponse {

    private String trackingEventCity;
    private String trackingEventCountry;
    private String trackingEventState;
    private String trackingEventZipCode;

    public String getTrackingEventCity() {
        return trackingEventCity;
    }

    public void setTrackingEventCity(String trackingEventCity) {
        this.trackingEventCity = trackingEventCity;
    }

    public String getTrackingEventCountry() {
        return trackingEventCountry;
    }

    public void setTrackingEventCountry(String trackingEventCountry) {
        this.trackingEventCountry = trackingEventCountry;
    }

    public String getTrackingEventState() {
        return trackingEventState;
    }

    public void setTrackingEventState(String trackingEventState) {
        this.trackingEventState = trackingEventState;
    }

    public String getTrackingEventZipCode() {
        return trackingEventZipCode;
    }

    public void setTrackingEventZipCode(String trackingEventZipCode) {
        this.trackingEventZipCode = trackingEventZipCode;
    }

}
