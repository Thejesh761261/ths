
package com.order.resource.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class TrackingEventListResourceResponse {

    private String trackingEventDate;
    private String trackingEventDetails;
    private TrackingEventLocResourceResponse trackingEventLoc;
    private String trackingEventStatus;
    private String trackingEventTime;
    private String trackingEventTimestamp;

    public String getTrackingEventDate() {
        return trackingEventDate;
    }

    public void setTrackingEventDate(String trackingEventDate) {
        this.trackingEventDate = trackingEventDate;
    }

    public String getTrackingEventDetails() {
        return trackingEventDetails;
    }

    public void setTrackingEventDetails(String trackingEventDetails) {
        this.trackingEventDetails = trackingEventDetails;
    }

    public TrackingEventLocResourceResponse getTrackingEventLoc() {
        return trackingEventLoc;
    }

    public void setTrackingEventLoc(TrackingEventLocResourceResponse trackingEventLoc) {
        this.trackingEventLoc = trackingEventLoc;
    }

    public String getTrackingEventStatus() {
        return trackingEventStatus;
    }

    public void setTrackingEventStatus(String trackingEventStatus) {
        this.trackingEventStatus = trackingEventStatus;
    }

    public String getTrackingEventTime() {
        return trackingEventTime;
    }

    public void setTrackingEventTime(String trackingEventTime) {
        this.trackingEventTime = trackingEventTime;
    }

    public String getTrackingEventTimestamp() {
        return trackingEventTimestamp;
    }

    public void setTrackingEventTimestamp(String trackingEventTimestamp) {
        this.trackingEventTimestamp = trackingEventTimestamp;
    }

}
